<?php
/*
  Template name: Index
*/



get_header(); ?>
<div class="hardemptyspace">
<br><br><br><br>
</div
<?php get_footer(); ?>
