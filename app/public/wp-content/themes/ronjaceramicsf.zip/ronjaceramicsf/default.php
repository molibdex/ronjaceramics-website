<?php
/*
  Template name: Default
*/

get_header(); ?>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<?php get_footer(); ?>
