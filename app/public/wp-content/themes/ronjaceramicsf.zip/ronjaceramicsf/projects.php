<?php
/*
  Template name: Projects
*/

get_header(); ?>
<br>
<br>
<br>
PROJEKTY
<br>
<br>
<br>
<?php get_footer(); ?>
